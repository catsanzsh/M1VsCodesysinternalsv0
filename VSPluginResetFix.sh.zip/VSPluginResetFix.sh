#!/bin/bash

echo "Plugin Resetter 0.1a"

# Confirm before proceeding
read -p "This will reset VS Code and Git configurations on your system. Do you want to continue? (y/n): " choice
if [[ "$choice" != "y" ]]; then
    echo "Operation canceled."
    exit 0
fi

echo "Resetting VS Code settings and extensions..."

# Delete VS Code user settings
rm -rf "$HOME/Library/Application Support/Code/User"

# Delete VS Code extensions
rm -rf "$HOME/.vscode/extensions"
rm -rf "$HOME/Library/Application Support/Code/Extensions"

echo "Resetting Git configurations..."

# Delete Git global configuration
rm -rf "$HOME/.gitconfig"

# Delete Git credentials
rm -rf "$HOME/.git-credentials"

echo "Operation completed. Exiting..."
# Optional: Remove VS Code application
read -p "Do you want to remove the VS Code application as well? (y/n): " remove_vscode
if [[ "$remove_vscode" == "y" ]]; then
    sudo rm -rf "/Applications/Visual Studio Code.app"
    echo "VS Code application removed."
fi
